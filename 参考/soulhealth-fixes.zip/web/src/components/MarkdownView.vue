<template>
  <div class="md" v-html="html"></div>
</template>

<script setup>
import { computed } from 'vue'
import { marked } from 'marked'

const props = defineProps({ source: { type: String, default: '' } })
marked.setOptions({ breaks: true, gfm: true })

// ---- 输出净化（重要）----
// 本组件渲染的内容来自大模型回答与报告解析结果，属于不可信输入。
// v-html 直出会带来 XSS 风险，这里按白名单做 DOM 级清洗：
//   - 危险标签整体移除（脚本/样式/框架/表单/媒体等）
//   - 白名单外的其他标签只保留文字内容
//   - 属性只保留 class 与 a 的合法 href（http/https/mailto），
//     其余（style、on* 事件等）一律剥掉
const DROP_TAGS = new Set(['SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'EMBED',
  'LINK', 'META', 'FORM', 'INPUT', 'BUTTON', 'TEXTAREA', 'SELECT',
  'VIDEO', 'AUDIO', 'SOURCE', 'BASE'])
const ALLOW_TAGS = new Set(['P', 'BR', 'HR', 'STRONG', 'EM', 'B', 'I', 'U',
  'S', 'DEL', 'CODE', 'PRE', 'BLOCKQUOTE', 'UL', 'OL', 'LI',
  'H1', 'H2', 'H3', 'H4', 'H5', 'H6',
  'TABLE', 'THEAD', 'TBODY', 'TR', 'TH', 'TD', 'A', 'SPAN', 'DIV'])

function sanitize(dirty) {
  const doc = new DOMParser().parseFromString(dirty, 'text/html')
  const walk = (node) => {
    for (const el of [...node.children]) {
      if (DROP_TAGS.has(el.tagName)) { el.remove(); continue }
      walk(el)
      if (!ALLOW_TAGS.has(el.tagName)) {
        el.replaceWith(...el.childNodes)   // 去壳留字
        continue
      }
      for (const attr of [...el.attributes]) {
        const n = attr.name.toLowerCase()
        if (n === 'class') continue
        if (el.tagName === 'A' && n === 'href'
            && /^(https?:|mailto:)/i.test(attr.value.trim())) {
          el.setAttribute('rel', 'noopener noreferrer')
          el.setAttribute('target', '_blank')
          continue
        }
        el.removeAttribute(attr.name)
      }
    }
  }
  walk(doc.body)
  return doc.body.innerHTML
}

const html = computed(() => sanitize(marked.parse(props.source || '')))
</script>
